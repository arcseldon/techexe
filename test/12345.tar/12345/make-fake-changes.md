# make a fake change

Actually write a line in a log if the log does not exist
